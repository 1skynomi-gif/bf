import { useStore } from './store/useStore';
import { HomeScreen } from './components/screens/HomeScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { ClassicSettingsScreen } from './components/screens/ClassicSettingsScreen';
import { ClassicGame } from './components/game/ClassicGame';
import { AdvancedSettingsScreen } from './components/screens/AdvancedSettingsScreen';
import { AdvancedGame } from './components/game/AdvancedGame';
import { ArithmeticSettingsScreen } from './components/screens/ArithmeticSettingsScreen';
import { ArithmeticGame } from './components/game/ArithmeticGame';
import { AlienSettingsScreen } from './components/screens/AlienSettingsScreen';
import { AlienGame } from './components/game/AlienGame';

function App() {
  const { currentScreen, settings } = useStore();
  const dark = settings.theme === 'dark';

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home': return <HomeScreen />;
      case 'profile': return <ProfileScreen />;
      case 'settings': return <SettingsScreen />;
      case 'classic-settings': return <ClassicSettingsScreen />;
      case 'classic-game': return <ClassicGame />;
      case 'advanced-settings': return <AdvancedSettingsScreen />;
      case 'advanced-game': return <AdvancedGame />;
      case 'arithmetic-settings': return <ArithmeticSettingsScreen />;
      case 'arithmetic-game': return <ArithmeticGame />;
      case 'alien-settings': return <AlienSettingsScreen />;
      case 'alien-game': return <AlienGame />;
      default: return <HomeScreen />;
    }
  };

  return (
    <div className={`h-full w-full max-w-md mx-auto relative overflow-hidden ${dark ? 'bg-dark-bg' : 'bg-gray-50'}`}>
      {/* Animated background */}
      {settings.particleEffects && settings.animationsEnabled && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
          <div className={`absolute w-72 h-72 rounded-full blur-3xl opacity-10 ${dark ? 'bg-brand-500' : 'bg-brand-200'}`}
            style={{ top: '-10%', right: '-20%', animation: 'float 8s ease-in-out infinite' }} />
          <div className={`absolute w-64 h-64 rounded-full blur-3xl opacity-8 ${dark ? 'bg-neon-cyan' : 'bg-cyan-200'}`}
            style={{ bottom: '-10%', left: '-20%', animation: 'float 10s ease-in-out infinite reverse' }} />
          <div className={`absolute w-48 h-48 rounded-full blur-3xl opacity-5 ${dark ? 'bg-neon-purple' : 'bg-purple-200'}`}
            style={{ top: '40%', left: '50%', animation: 'float 7s ease-in-out infinite 1s' }} />
        </div>
      )}
      <div className="relative z-10 h-full">
        {renderScreen()}
      </div>
    </div>
  );
}

export default App;
