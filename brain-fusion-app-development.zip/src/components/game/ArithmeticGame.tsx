import { useState, useEffect, useCallback, useRef } from 'react';
import { useStore } from '../../store/useStore';
import { speakWord, playCorrectSound, playWrongSound } from '../../utils/audio';
import { SHAPES, COLORS } from '../../utils/stimulusGenerator';
import { X, Pause, Play } from 'lucide-react';

interface ArithStimulus {
  number: number;
  position: number;
  operation: 'add' | 'subtract' | 'multiply';
  shape?: number;
  color?: number;
}

interface ChannelResult {
  hits: number; misses: number; falseAlarms: number; correctRejections: number; accuracy: number;
}

export function ArithmeticGame() {
  const { settings, arithmeticSettings, setScreen, addSession, addXP } = useStore();
  const dark = settings.theme === 'dark';
  const anims = settings.animationsEnabled;

  const [phase, setPhase] = useState<'ready' | 'playing' | 'paused' | 'result'>('ready');
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [sequence, setSequence] = useState<ArithStimulus[]>([]);
  const [showStimulus, setShowStimulus] = useState(false);
  const [startTime, setStartTime] = useState(0);
  const [currentN, setCurrentN] = useState(arithmeticSettings.n);
  const [currentSpeed, setCurrentSpeed] = useState(arithmeticSettings.speed);

  // User inputs
  const [arithmeticAnswer, setArithmeticAnswer] = useState('');
  const [comparisonAnswer, setComparisonAnswer] = useState<'greater' | 'less' | 'equal' | null>(null);
  const [positionResponse, setPositionResponse] = useState<Set<number>>(new Set());
  const [_shapeResponse, setShapeResponse] = useState<Set<number>>(new Set());
  const [_colorResponse, setColorResponse] = useState<Set<number>>(new Set());

  // Results tracking
  const [arithmeticResults, setArithmeticResults] = useState<{ correct: number; wrong: number }>({ correct: 0, wrong: 0 });
  const [comparisonResults, setComparisonResults] = useState<{ correct: number; wrong: number }>({ correct: 0, wrong: 0 });
  const [posResult, setPosResult] = useState<ChannelResult>({ hits: 0, misses: 0, falseAlarms: 0, correctRejections: 0, accuracy: 0 });
  const [totalAccuracy, setTotalAccuracy] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [feedback, setFeedback] = useState<string>('');

  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pauseRef = useRef(false);

  const generateGame = useCallback(() => {
    const seq: ArithStimulus[] = [];
    const gridSize = arithmeticSettings.gridSize;
    const ops: ('add' | 'subtract' | 'multiply')[] = ['add', 'subtract', 'multiply'];

    for (let i = 0; i < arithmeticSettings.stimuliCount; i++) {
      const num = Math.floor(Math.random() * 99) + 1;
      const pos = Math.floor(Math.random() * gridSize * gridSize);
      const op = ops[Math.floor(Math.random() * 3)];

      const stim: ArithStimulus = { number: num, position: pos, operation: op };
      if (arithmeticSettings.channels.shape) stim.shape = Math.floor(Math.random() * SHAPES.length);
      if (arithmeticSettings.channels.color) stim.color = Math.floor(Math.random() * COLORS.length);

      // Fix subtraction: ensure current number <= n-back number
      if (op === 'subtract' && i >= currentN) {
        const prevNum = seq[i - currentN].number;
        if (num > prevNum) {
          stim.number = Math.floor(Math.random() * prevNum) + 1;
        }
      }

      seq.push(stim);
    }

    setSequence(seq);
    setCurrentIndex(-1);
    setPositionResponse(new Set());
    setShapeResponse(new Set());
    setColorResponse(new Set());
    setArithmeticResults({ correct: 0, wrong: 0 });
    setComparisonResults({ correct: 0, wrong: 0 });
  }, [arithmeticSettings, currentN]);

  useEffect(() => { generateGame(); }, []);

  const startGame = useCallback(() => {
    setPhase('playing');
    setStartTime(Date.now());
    setCurrentIndex(0);
    setShowStimulus(true);
    setSubmitted(false);
  }, []);

  useEffect(() => {
    if (phase !== 'playing' || currentIndex < 0 || currentIndex >= sequence.length) return;

    const stim = sequence[currentIndex];
    setSubmitted(false);
    setArithmeticAnswer('');
    setComparisonAnswer(null);

    // Speak operation
    if (arithmeticSettings.channels.arithmetic && currentIndex >= currentN) {
      const opWord = stim.operation === 'add' ? 'plus' : stim.operation === 'subtract' ? 'minus' : 'times';
      const rate = Math.max(0.7, Math.min(2, 3000 / currentSpeed));
      setTimeout(() => speakWord(opWord, rate), 200);
    }

    // Dynamic N
    if (arithmeticSettings.taskSwitching.dynamicN) {
      const chance = arithmeticSettings.taskSwitching.dynamicNIntensity / 10;
      if (Math.random() < chance) {
        const newN = Math.floor(Math.random() * (arithmeticSettings.taskSwitching.dynamicNMax - arithmeticSettings.taskSwitching.dynamicNMin + 1)) + arithmeticSettings.taskSwitching.dynamicNMin;
        setCurrentN(newN);
      }
    }

    // Dynamic Speed
    if (arithmeticSettings.taskSwitching.dynamicSpeed) {
      const chance = arithmeticSettings.taskSwitching.dynamicSpeedIntensity / 10;
      if (Math.random() < chance) {
        const newSpeed = Math.floor(Math.random() * (arithmeticSettings.taskSwitching.dynamicSpeedMax - arithmeticSettings.taskSwitching.dynamicSpeedMin + 1)) + arithmeticSettings.taskSwitching.dynamicSpeedMin;
        setCurrentSpeed(newSpeed);
      }
    }

    setShowStimulus(true);

    timerRef.current = setTimeout(() => {
      if (pauseRef.current) return;
      setShowStimulus(false);
      setCurrentIndex(prev => {
        if (prev >= sequence.length - 1) {
          setPhase('result');
          return prev;
        }
        return prev + 1;
      });
    }, currentSpeed);

    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [phase, currentIndex, currentSpeed]);

  const submitArithmetic = () => {
    if (submitted || currentIndex < currentN || !arithmeticSettings.channels.arithmetic) return;
    setSubmitted(true);

    const stim = sequence[currentIndex];
    const prev = sequence[currentIndex - currentN];
    let correctAnswer: number;
    
    if (stim.operation === 'add') correctAnswer = stim.number + prev.number;
    else if (stim.operation === 'subtract') correctAnswer = stim.number - prev.number;
    else correctAnswer = stim.number * prev.number;

    const userAnswer = parseInt(arithmeticAnswer);
    if (userAnswer === correctAnswer) {
      setArithmeticResults(r => ({ ...r, correct: r.correct + 1 }));
      setFeedback('✓ Correct!');
      if (settings.soundEnabled) playCorrectSound();
    } else {
      setArithmeticResults(r => ({ ...r, wrong: r.wrong + 1 }));
      setFeedback(`✗ ${correctAnswer}`);
      if (settings.soundEnabled) playWrongSound();
    }
    setTimeout(() => setFeedback(''), 500);
  };

  const submitComparison = (answer: 'greater' | 'less' | 'equal') => {
    if (currentIndex < currentN || !arithmeticSettings.channels.comparison) return;
    setComparisonAnswer(answer);

    const stim = sequence[currentIndex];
    const prev = sequence[currentIndex - currentN];
    let correct: 'greater' | 'less' | 'equal';
    if (stim.number > prev.number) correct = 'greater';
    else if (stim.number < prev.number) correct = 'less';
    else correct = 'equal';

    if (answer === correct) {
      setComparisonResults(r => ({ ...r, correct: r.correct + 1 }));
      if (settings.soundEnabled) playCorrectSound();
    } else {
      setComparisonResults(r => ({ ...r, wrong: r.wrong + 1 }));
      if (settings.soundEnabled) playWrongSound();
    }
  };

  // Results
  useEffect(() => {
    if (phase !== 'result') return;

    const posRes = (() => {
      let hits = 0, misses = 0, falseAlarms = 0, correctRejections = 0;
      for (let i = currentN; i < sequence.length; i++) {
        const isMatch = sequence[i].position === sequence[i - currentN].position;
        const responded = positionResponse.has(i);
        if (isMatch && responded) hits++;
        else if (isMatch && !responded) misses++;
        else if (!isMatch && responded) falseAlarms++;
        else correctRejections++;
      }
      const totalMatches = hits + misses;
      const hitRate = totalMatches > 0 ? hits / totalMatches : 0;
      const faPenalty = falseAlarms > 0 ? (falseAlarms / (falseAlarms + correctRejections)) * 0.5 : 0;
      const accuracy = Math.max(0, Math.min(100, (hitRate * 100) - (faPenalty * 30)));
      return { hits, misses, falseAlarms, correctRejections, accuracy };
    })();

    setPosResult(posRes);

    let accSum = 0;
    let accCount = 0;

    if (arithmeticSettings.channels.position) { accSum += posRes.accuracy; accCount++; }
    if (arithmeticSettings.channels.arithmetic) {
      const total = arithmeticResults.correct + arithmeticResults.wrong;
      const acc = total > 0 ? (arithmeticResults.correct / total) * 100 : 0;
      accSum += acc; accCount++;
    }
    if (arithmeticSettings.channels.comparison) {
      const total = comparisonResults.correct + comparisonResults.wrong;
      const acc = total > 0 ? (comparisonResults.correct / total) * 100 : 0;
      accSum += acc; accCount++;
    }

    const avg = accCount > 0 ? accSum / accCount : 0;
    setTotalAccuracy(avg);

    const duration = Math.round((Date.now() - startTime) / 1000);
    const xp = Math.round(avg * 0.6 + arithmeticSettings.n * 10 + 15);
    addSession({
      mode: 'arithmetic',
      date: new Date().toISOString(),
      accuracy: avg,
      n: arithmeticSettings.n,
      channels: Object.entries(arithmeticSettings.channels).filter(([_, v]) => v).map(([k]) => k),
      hits: posRes.hits + arithmeticResults.correct + comparisonResults.correct,
      misses: posRes.misses + arithmeticResults.wrong + comparisonResults.wrong,
      falseAlarms: posRes.falseAlarms,
      correctRejections: posRes.correctRejections,
      xpEarned: xp,
      duration,
      channelDetails: { position: posRes },
    });
    addXP(xp);
  }, [phase]);

  const togglePause = () => {
    if (phase === 'playing') { pauseRef.current = true; setPhase('paused'); if (timerRef.current) clearTimeout(timerRef.current); }
    else if (phase === 'paused') { pauseRef.current = false; setPhase('playing'); setCurrentIndex(p => p); }
  };

  if (phase === 'ready') {
    return (
      <div className={`h-full flex flex-col items-center justify-center ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
        <div className={`w-24 h-24 rounded-3xl flex items-center justify-center bg-gradient-to-br from-neon-green to-emerald-600 mb-6 ${anims ? 'animate-pulse-glow' : ''}`}>
          <span className="text-5xl">🧮</span>
        </div>
        <h2 className="text-2xl font-black mb-2">Arithmetic {arithmeticSettings.n}-Back</h2>
        <p className={`text-sm mb-8 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>{arithmeticSettings.stimuliCount} stimuli</p>
        <button onClick={startGame} className="w-20 h-20 rounded-full bg-gradient-to-r from-neon-green to-emerald-600 flex items-center justify-center shadow-lg shadow-neon-green/40 active:scale-95 transition-transform">
          <Play className="w-10 h-10 text-white ml-1" />
        </button>
        <button onClick={() => setScreen('arithmetic-settings')} className={`mt-6 text-sm ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>← Back</button>
      </div>
    );
  }

  if (phase === 'result') {
    return (
      <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
        <div className="px-5 pt-6 pb-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Results</h1>
          <button onClick={() => setScreen('arithmetic-settings')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}><X className="w-5 h-5" /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
          <div className={`rounded-3xl p-6 text-center ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
            <p className={`text-xs uppercase tracking-wider mb-2 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Overall Accuracy</p>
            <p className={`text-6xl font-black ${totalAccuracy >= 80 ? 'text-green-400' : totalAccuracy >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>{totalAccuracy.toFixed(1)}%</p>
          </div>

          {arithmeticSettings.channels.arithmetic && (
            <div className={`rounded-3xl p-5 ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
              <h3 className="font-bold text-sm mb-2">🧮 Arithmetic</h3>
              <p className="text-xs">Correct: <span className="text-green-400 font-bold">{arithmeticResults.correct}</span> | Wrong: <span className="text-red-400 font-bold">{arithmeticResults.wrong}</span></p>
            </div>
          )}

          {arithmeticSettings.channels.comparison && (
            <div className={`rounded-3xl p-5 ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
              <h3 className="font-bold text-sm mb-2">⚖️ Comparison</h3>
              <p className="text-xs">Correct: <span className="text-green-400 font-bold">{comparisonResults.correct}</span> | Wrong: <span className="text-red-400 font-bold">{comparisonResults.wrong}</span></p>
            </div>
          )}

          {arithmeticSettings.channels.position && (
            <div className={`rounded-3xl p-5 ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
              <h3 className="font-bold text-sm mb-2">📍 Position</h3>
              <div className="grid grid-cols-4 gap-2">
                <div className="text-center"><p className="text-green-400 font-bold">{posResult.hits}</p><p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Hits</p></div>
                <div className="text-center"><p className="text-red-400 font-bold">{posResult.misses}</p><p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Miss</p></div>
                <div className="text-center"><p className="text-orange-400 font-bold">{posResult.falseAlarms}</p><p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>FA</p></div>
                <div className="text-center"><p className="text-blue-400 font-bold">{posResult.correctRejections}</p><p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>CR</p></div>
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <button onClick={() => { generateGame(); setPhase('ready'); }} className="flex-1 py-3 rounded-2xl font-bold text-sm bg-gradient-to-r from-neon-green to-emerald-600 text-white">Again</button>
            <button onClick={() => setScreen('home')} className={`flex-1 py-3 rounded-2xl font-bold text-sm ${dark ? 'bg-dark-surface text-dark-text' : 'bg-gray-100 text-gray-700'}`}>Home</button>
          </div>
        </div>
      </div>
    );
  }

  const stim = sequence[currentIndex];
  const gridSize = arithmeticSettings.gridSize;

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      {phase === 'paused' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="text-center">
            <p className="text-3xl font-black text-white mb-4">⏸ Paused</p>
            <button onClick={togglePause} className="px-8 py-3 rounded-2xl bg-gradient-to-r from-neon-green to-emerald-600 text-white font-bold">Resume</button>
          </div>
        </div>
      )}

      <div className="px-4 pt-3 pb-1 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold px-2 py-1 rounded-lg ${dark ? 'bg-neon-green/20 text-neon-green' : 'bg-green-50 text-green-600'}`}>N={currentN}</span>
          <span className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>{currentIndex + 1}/{sequence.length}</span>
        </div>
        <div className="flex gap-1">
          <button onClick={togglePause} className={`w-8 h-8 rounded-lg flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            <Pause className="w-3 h-3" />
          </button>
          <button onClick={() => setScreen('arithmetic-settings')} className={`w-8 h-8 rounded-lg flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      <div className="px-4 pb-1">
        <div className={`w-full h-1 rounded-full overflow-hidden ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
          <div className="h-full rounded-full bg-gradient-to-r from-neon-green to-emerald-600 transition-all duration-300" style={{ width: `${((currentIndex + 1) / sequence.length) * 100}%` }} />
        </div>
      </div>

      {/* Number display */}
      <div className="text-center py-3">
        {showStimulus && stim && (
          <div className={`text-5xl font-black ${dark ? 'text-neon-green' : 'text-green-500'}`}>{stim.number}</div>
        )}
        {showStimulus && stim && currentIndex >= currentN && (
          <p className={`text-xs mt-1 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
            {stim.operation === 'add' ? '➕' : stim.operation === 'subtract' ? '➖' : '✖️'} with {currentN}-back ({sequence[currentIndex - currentN]?.number})
          </p>
        )}
        {feedback && <p className="text-sm font-bold mt-1">{feedback}</p>}
      </div>

      {/* Grid */}
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="w-full max-w-[250px] aspect-square grid gap-1" style={{ gridTemplateColumns: `repeat(${gridSize}, 1fr)` }}>
          {Array.from({ length: gridSize * gridSize }, (_, i) => {
            const isActive = showStimulus && stim?.position === i;
            return (
              <div key={i}
                className={`rounded-xl flex items-center justify-center ${anims ? 'transition-all duration-150' : ''} ${
                  isActive ? 'bg-gradient-to-br from-neon-green/30 to-emerald-600/30 border-2 border-neon-green shadow-lg scale-95'
                    : dark ? 'bg-dark-surface/50 border border-dark-border/50' : 'bg-gray-100/50 border border-gray-200/50'
                }`}
              >
                {isActive && stim?.shape !== undefined && (
                  <span style={{ color: stim.color !== undefined ? COLORS[stim.color] : '#22c55e', fontSize: '20px' }}>
                    {['●','■','▲','◆','★','⬡','⬠','✚','♥'][stim.shape ?? 0]}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Controls */}
      <div className="px-4 pb-6 pt-2 space-y-3">
        {/* Arithmetic input */}
        {arithmeticSettings.channels.arithmetic && currentIndex >= currentN && (
          <div className="flex gap-2">
            <input
              type="number"
              value={arithmeticAnswer}
              onChange={e => setArithmeticAnswer(e.target.value)}
              placeholder="Answer"
              className={`flex-1 px-4 py-3 rounded-xl text-center font-bold ${dark ? 'bg-dark-surface text-dark-text border border-dark-border' : 'bg-white border border-gray-200'}`}
            />
            <button onClick={submitArithmetic} disabled={submitted}
              className="px-6 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-neon-green to-emerald-600 text-white disabled:opacity-30">
              ✓
            </button>
          </div>
        )}

        {/* Comparison buttons */}
        {arithmeticSettings.channels.comparison && currentIndex >= currentN && (
          <div className="flex gap-2">
            {(['less', 'equal', 'greater'] as const).map(c => (
              <button key={c} onClick={() => submitComparison(c)} disabled={comparisonAnswer !== null}
                className={`flex-1 py-3 rounded-xl font-bold text-sm ${comparisonAnswer === c ? 'bg-brand-500 text-white' : dark ? 'bg-dark-surface text-dark-text border border-dark-border' : 'bg-white border border-gray-200'} disabled:opacity-50`}>
                {c === 'less' ? '< Less' : c === 'equal' ? '= Equal' : '> Greater'}
              </button>
            ))}
          </div>
        )}

        {/* Position match */}
        {arithmeticSettings.channels.position && (
          <button
            onClick={() => {
              if (currentIndex < currentN || positionResponse.has(currentIndex)) return;
              const s = new Set(positionResponse); s.add(currentIndex); setPositionResponse(s);
              const isMatch = stim?.position === sequence[currentIndex - currentN]?.position;
              if (isMatch) { if (settings.soundEnabled) playCorrectSound(); }
              else { if (settings.soundEnabled) playWrongSound(); }
            }}
            disabled={currentIndex < currentN || positionResponse.has(currentIndex)}
            className={`w-full py-4 rounded-2xl font-bold text-sm ${positionResponse.has(currentIndex) ? 'bg-neon-green/30 text-neon-green' : dark ? 'bg-dark-surface border-2 border-neon-green/50 text-neon-green' : 'bg-white border-2 border-green-400 text-green-600'} disabled:opacity-30`}>
            📍 Position Match
          </button>
        )}
      </div>
    </div>
  );
}
