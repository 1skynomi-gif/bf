import { useStore } from '../../store/useStore';
import { Card } from '../ui/Card';
import { Slider } from '../ui/Slider';
import { Toggle } from '../ui/Toggle';
import { Button } from '../ui/Button';
import { ArrowLeft, Play, Brain } from 'lucide-react';

export function ClassicSettingsScreen() {
  const { settings, classicSettings, setClassicSettings, setScreen } = useStore();
  const dark = settings.theme === 'dark';

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      <div className="px-5 pt-6 pb-4 flex items-center gap-3">
        <button onClick={() => setScreen('home')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-xl font-bold">Classic N-Back</h1>
          <p className={`text-xs ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Position & Audio channels</p>
        </div>
        <Brain className={`w-6 h-6 ml-auto ${dark ? 'text-brand-400' : 'text-brand-500'}`} />
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
        <Card>
          <h3 className="font-bold text-sm mb-4">Core Settings</h3>
          <div className="space-y-5">
            <Slider label="N-Back Level" value={classicSettings.n} min={1} max={10} onChange={v => setClassicSettings({ n: v })} />
            <Slider label="Speed" value={classicSettings.speed} min={200} max={5000} step={100} onChange={v => setClassicSettings({ speed: v })} unit="ms" />
            <Slider label="Stimuli Per Session" value={classicSettings.stimuliCount} min={25} max={500} step={5} onChange={v => setClassicSettings({ stimuliCount: v })} />
          </div>
        </Card>

        <Card>
          <h3 className="font-bold text-sm mb-4">Channels</h3>
          <div className={`text-xs space-y-2 ${dark ? 'text-dark-muted' : 'text-gray-500'}`}>
            <p>📍 <strong className={dark ? 'text-dark-text' : 'text-gray-700'}>Position</strong> — 3×3 grid</p>
            <p>🔊 <strong className={dark ? 'text-dark-text' : 'text-gray-700'}>Audio</strong> — 9 letter sounds (TTS)</p>
            <p className={`text-[10px] mt-2 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
              25% of stimuli are matches per channel, distributed randomly
            </p>
          </div>
        </Card>

        <Card>
          <h3 className="font-bold text-sm mb-4">Adaptive Difficulty</h3>
          <Toggle
            label="Enable Adaptive"
            value={classicSettings.adaptiveEnabled}
            onChange={v => setClassicSettings({ adaptiveEnabled: v })}
            description="Auto-adjust N based on performance"
          />
          {classicSettings.adaptiveEnabled && (
            <div className="mt-3">
              <Slider
                label="Accuracy Threshold"
                value={classicSettings.adaptiveThreshold}
                min={60}
                max={95}
                step={5}
                onChange={v => setClassicSettings({ adaptiveThreshold: v })}
                unit="%"
              />
              <p className={`text-[10px] mt-2 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
                3 sessions above {classicSettings.adaptiveThreshold}% → N+1<br />
                2 sessions below {classicSettings.adaptiveThreshold}% → N-1
              </p>
            </div>
          )}
        </Card>
      </div>

      <div className="px-5 pb-6 pt-2">
        <Button
          onClick={() => setScreen('classic-game')}
          variant="primary"
          size="lg"
          className="w-full"
          icon={<Play className="w-5 h-5" />}
        >
          Start Training
        </Button>
      </div>
    </div>
  );
}
