import { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Card } from '../ui/Card';
import { Slider } from '../ui/Slider';
import { Toggle } from '../ui/Toggle';
import { Button } from '../ui/Button';
import { ArrowLeft, Play, Calculator } from 'lucide-react';

export function ArithmeticSettingsScreen() {
  const { settings, arithmeticSettings, setArithmeticSettings, setScreen } = useStore();
  const dark = settings.theme === 'dark';
  const [tab, setTab] = useState<'core' | 'taskSwitch'>('core');

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      <div className="px-5 pt-6 pb-2 flex items-center gap-3">
        <button onClick={() => setScreen('home')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">Arithmetic N-Back</h1>
          <p className={`text-xs ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Math meets working memory</p>
        </div>
        <Calculator className={`w-6 h-6 ${dark ? 'text-neon-green' : 'text-green-500'}`} />
      </div>

      <div className="px-5 py-2 flex gap-2">
        {[
          { id: 'core' as const, label: '⚙️ Core' },
          { id: 'taskSwitch' as const, label: '🔀 Task Switch' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              tab === t.id ? 'bg-gradient-to-r from-neon-green to-emerald-600 text-white'
                : dark ? 'bg-dark-surface text-dark-muted' : 'bg-gray-100 text-gray-500'
            }`}
          >{t.label}</button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
        {tab === 'core' && (
          <>
            <Card>
              <h3 className="font-bold text-sm mb-4">Base Parameters</h3>
              <div className="space-y-5">
                <Slider label="N-Back Level" value={arithmeticSettings.n} min={1} max={100} onChange={v => setArithmeticSettings({ n: v })} />
                <Slider label="Speed" value={arithmeticSettings.speed} min={100} max={250000} step={100} onChange={v => setArithmeticSettings({ speed: v })} unit="ms" formatValue={v => v >= 1000 ? `${(v/1000).toFixed(1)}s` : `${v}ms`} />
                <Slider label="Stimuli Per Session" value={arithmeticSettings.stimuliCount} min={25} max={10000} step={5} onChange={v => setArithmeticSettings({ stimuliCount: v })} />
                <Slider label="Match Percentage" value={arithmeticSettings.matchPercent} min={10} max={40} step={5} onChange={v => setArithmeticSettings({ matchPercent: v })} unit="%" />
                <Slider label="Grid Size" value={arithmeticSettings.gridSize} min={3} max={9} onChange={v => setArithmeticSettings({ gridSize: v })} formatValue={v => `${v}×${v}`} />
              </div>
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Channels</h3>
              <div className="space-y-2">
                <Toggle label="📍 Position" value={arithmeticSettings.channels.position} onChange={v => setArithmeticSettings({ channels: { ...arithmeticSettings.channels, position: v } })} />
                <Toggle label="🔊 Arithmetic (Add/Sub/Mul)" value={arithmeticSettings.channels.arithmetic} onChange={v => setArithmeticSettings({ channels: { ...arithmeticSettings.channels, arithmetic: v } })} description="Audio tells operation, calculate with n-back number" />
                <Toggle label="⚖️ Comparison (> < =)" value={arithmeticSettings.channels.comparison} onChange={v => setArithmeticSettings({ channels: { ...arithmeticSettings.channels, comparison: v } })} description="Compare current number with n-back number" />
                <Toggle label="🔷 Shape" value={arithmeticSettings.channels.shape} onChange={v => setArithmeticSettings({ channels: { ...arithmeticSettings.channels, shape: v } })} />
                <Toggle label="🎨 Color" value={arithmeticSettings.channels.color} onChange={v => setArithmeticSettings({ channels: { ...arithmeticSettings.channels, color: v } })} />
              </div>
            </Card>
          </>
        )}

        {tab === 'taskSwitch' && (
          <>
            <Card>
              <h3 className="font-bold text-sm mb-4">Dynamic N</h3>
              <Toggle label="Enable Dynamic N" value={arithmeticSettings.taskSwitching.dynamicN} onChange={v => setArithmeticSettings({ taskSwitching: { ...arithmeticSettings.taskSwitching, dynamicN: v } })} />
              {arithmeticSettings.taskSwitching.dynamicN && (
                <div className="mt-3 space-y-4">
                  <Slider label="Min N" value={arithmeticSettings.taskSwitching.dynamicNMin} min={1} max={99} onChange={v => setArithmeticSettings({ taskSwitching: { ...arithmeticSettings.taskSwitching, dynamicNMin: v } })} />
                  <Slider label="Max N" value={arithmeticSettings.taskSwitching.dynamicNMax} min={2} max={100} onChange={v => setArithmeticSettings({ taskSwitching: { ...arithmeticSettings.taskSwitching, dynamicNMax: v } })} />
                  <Slider label="Intensity" value={arithmeticSettings.taskSwitching.dynamicNIntensity} min={1} max={10} onChange={v => setArithmeticSettings({ taskSwitching: { ...arithmeticSettings.taskSwitching, dynamicNIntensity: v } })} />
                </div>
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Dynamic Speed</h3>
              <Toggle label="Enable Dynamic Speed" value={arithmeticSettings.taskSwitching.dynamicSpeed} onChange={v => setArithmeticSettings({ taskSwitching: { ...arithmeticSettings.taskSwitching, dynamicSpeed: v } })} />
              {arithmeticSettings.taskSwitching.dynamicSpeed && (
                <div className="mt-3 space-y-4">
                  <Slider label="Min Speed" value={arithmeticSettings.taskSwitching.dynamicSpeedMin} min={100} max={249000} step={100} onChange={v => setArithmeticSettings({ taskSwitching: { ...arithmeticSettings.taskSwitching, dynamicSpeedMin: v } })} unit="ms" formatValue={v => v >= 1000 ? `${(v/1000).toFixed(1)}s` : `${v}ms`} />
                  <Slider label="Max Speed" value={arithmeticSettings.taskSwitching.dynamicSpeedMax} min={200} max={250000} step={100} onChange={v => setArithmeticSettings({ taskSwitching: { ...arithmeticSettings.taskSwitching, dynamicSpeedMax: v } })} unit="ms" formatValue={v => v >= 1000 ? `${(v/1000).toFixed(1)}s` : `${v}ms`} />
                  <Slider label="Intensity" value={arithmeticSettings.taskSwitching.dynamicSpeedIntensity} min={1} max={10} onChange={v => setArithmeticSettings({ taskSwitching: { ...arithmeticSettings.taskSwitching, dynamicSpeedIntensity: v } })} />
                </div>
              )}
            </Card>
          </>
        )}
      </div>

      <div className="px-5 pb-6 pt-2">
        <Button onClick={() => setScreen('arithmetic-game')} variant="primary" size="lg" className="w-full bg-gradient-to-r from-neon-green to-emerald-600" icon={<Play className="w-5 h-5" />}>
          Start Training
        </Button>
      </div>
    </div>
  );
}
