import { useStore } from '../../store/useStore';
import { Card } from '../ui/Card';
import { ArrowLeft, Trophy, Target, Clock, Flame, Star, Award } from 'lucide-react';

export function ProfileScreen() {
  const { settings, profile, sessionHistory, setScreen, setProfile } = useStore();
  const dark = settings.theme === 'dark';

  const recentSessions = [...sessionHistory].reverse().slice(0, 10);
  const avgAccuracy = sessionHistory.length > 0
    ? sessionHistory.reduce((a, s) => a + s.accuracy, 0) / sessionHistory.length
    : 0;

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      <div className="px-5 pt-6 pb-4 flex items-center gap-3">
        <button onClick={() => setScreen('home')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Profile</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
        {/* Profile Header */}
        <Card glow>
          <div className="text-center">
            <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-brand-500 to-neon-cyan flex items-center justify-center mb-3 shadow-lg shadow-brand-500/30">
              <span className="text-3xl">🧠</span>
            </div>
            <input
              type="text"
              value={profile.name}
              onChange={e => setProfile({ name: e.target.value })}
              className={`text-xl font-black text-center bg-transparent border-none outline-none w-full ${dark ? 'text-dark-text' : 'text-gray-900'}`}
              maxLength={20}
            />
            <p className={`text-sm mt-1 ${dark ? 'text-neon-cyan' : 'text-brand-500'}`}>
              <Award className="w-4 h-4 inline mr-1" />
              {profile.title}
            </p>
            <div className="mt-3">
              <div className="flex items-center justify-center gap-2 mb-1">
                <span className={`text-xs font-bold ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Level {profile.level}</span>
                <span className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
                  {profile.xp}/{profile.xpToNext} XP
                </span>
              </div>
              <div className={`w-full h-3 rounded-full overflow-hidden ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
                <div
                  className="h-full rounded-full bg-gradient-to-r from-brand-500 via-neon-cyan to-neon-green transition-all duration-700"
                  style={{ width: `${(profile.xp / profile.xpToNext) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <Card>
            <div className="text-center">
              <Trophy className={`w-5 h-5 mx-auto mb-1 ${dark ? 'text-yellow-400' : 'text-yellow-500'}`} />
              <p className="text-lg font-black">{profile.totalSessions}</p>
              <p className={`text-[9px] uppercase ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Sessions</p>
            </div>
          </Card>
          <Card>
            <div className="text-center">
              <Target className={`w-5 h-5 mx-auto mb-1 ${dark ? 'text-neon-cyan' : 'text-brand-500'}`} />
              <p className="text-lg font-black">{avgAccuracy.toFixed(1)}%</p>
              <p className={`text-[9px] uppercase ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Avg Acc</p>
            </div>
          </Card>
          <Card>
            <div className="text-center">
              <Flame className={`w-5 h-5 mx-auto mb-1 text-orange-400`} />
              <p className="text-lg font-black">{profile.streak}</p>
              <p className={`text-[9px] uppercase ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Streak</p>
            </div>
          </Card>
        </div>

        {/* Level Titles */}
        <Card>
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
            <Star className="w-4 h-4 text-yellow-400" /> Title Milestones
          </h3>
          <div className="space-y-2">
            {[
              [1, 'Novice Mind'], [5, 'Apprentice Thinker'], [10, 'Cognitive Explorer'],
              [15, 'Neural Pathfinder'], [20, 'Synapse Warrior'], [25, 'Cortex Commander'],
              [30, 'Memory Architect'], [35, 'Neural Titan'], [40, 'Quantum Thinker'],
              [45, 'Brain Overlord'], [50, 'Cognitive Maestro'], [60, 'Neural Sovereign'],
              [70, 'Mind Dimension Master'], [80, 'Cerebral Ascendant'], [90, 'Omega Brain'],
              [100, 'Transcendent Mind'],
            ].map(([lvl, title]) => (
              <div key={String(lvl)} className={`flex items-center gap-2 text-xs ${profile.level >= (lvl as number) ? '' : 'opacity-40'}`}>
                <span className={`w-8 text-right font-bold ${dark ? 'text-brand-400' : 'text-brand-600'}`}>Lv.{String(lvl)}</span>
                <span className={`flex-1 ${profile.level >= (lvl as number) ? (dark ? 'text-neon-cyan' : 'text-brand-500') : ''}`}>
                  {profile.level >= (lvl as number) ? '✓ ' : '🔒 '}{String(title)}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Recent History */}
        <Card>
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4" /> Recent Sessions
          </h3>
          {recentSessions.length === 0 ? (
            <p className={`text-xs text-center py-4 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>No sessions yet</p>
          ) : (
            <div className="space-y-2">
              {recentSessions.map((s, i) => (
                <div key={i} className={`flex items-center justify-between py-2 px-3 rounded-xl ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                  <div>
                    <p className="text-xs font-bold capitalize">{s.mode} N-Back</p>
                    <p className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
                      N={s.n} • {new Date(s.date).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-black ${s.accuracy >= 80 ? 'text-green-400' : s.accuracy >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                      {s.accuracy.toFixed(1)}%
                    </p>
                    <p className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>+{s.xpEarned}xp</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
