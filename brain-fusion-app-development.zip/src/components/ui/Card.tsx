import React from 'react';
import { useStore } from '../../store/useStore';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  glow?: boolean;
}

export function Card({ children, className = '', onClick, glow }: CardProps) {
  const dark = useStore(s => s.settings.theme) === 'dark';
  const anims = useStore(s => s.settings.animationsEnabled);

  return (
    <div
      onClick={onClick}
      className={`rounded-3xl p-5 ${anims ? 'transition-all duration-300' : ''} ${
        onClick ? 'cursor-pointer active:scale-[0.98]' : ''
      } ${
        dark
          ? `bg-dark-card border border-dark-border ${glow ? 'shadow-lg shadow-brand-500/10' : ''}`
          : `bg-white border border-gray-100 shadow-sm ${glow ? 'shadow-lg shadow-brand-500/10' : ''}`
      } ${className}`}
    >
      {children}
    </div>
  );
}
